var mysqlModel = require('mysql');


var con = mysqlModel.createConnection({
    host: "localhost",
    user: "beavoafw_beavertail",
    password: "beavertest1",
    database: "beavoafw_beavertail"
 });

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!")
});


module.exports = con; 

const router = require('./index');
var con = require('./db');



router.get('/createNews', function(req, res, next) {
    res.render('createNews');
});

router.post('/submitNews', function(req, res, next) {
    console.log(req.body);
    let ssn = req.session;
    let title = req.body.title;
    let body = req.body.body;
    let dateFrom = req.body.dateFrom;
    let dateTo = req.body.dateTo;
    let tags = req.body.tags;
    let url = req.body.url;
    let sql = "INSERT INTO newsArticles (userName, title, body, dateFrom, dateTo, tags, url) VALUES ('" + ssn.userName + "', '" + title + "', '" + body + "', '" + dateFrom + "', '" + dateTo + "', '" + tags + "', '" + url + "')";
    con.query(sql, function (err, result) {
        if (err){
            throw err;
        } 
        console.log("Record inserted successfully");
        res.redirect('createNews');
    });
});